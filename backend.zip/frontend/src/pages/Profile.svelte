<script>
  import { auth } from '../lib/stores';
</script>

<div class="max-w-2xl mx-auto space-y-6">
  <div>
    <h1 class="text-3xl font-geist font-bold text-black">Profile</h1>
    <p class="mt-1 text-sm font-inter text-vercel-gray-600">
      Manage your account settings
    </p>
  </div>

  <div class="card p-6">
    <h2 class="text-xl font-geist font-semibold text-black mb-4">Account Information</h2>
    
    <div class="space-y-4">
      <div>
        <label for="email" class="label">Email</label>
        <input 
          id="email"
          type="email" 
          class="input" 
          value={$auth.user?.email || ''} 
          disabled 
        />
      </div>

      <div>
        <label for="role" class="label">Role</label>
        <input 
          id="role"
          type="text" 
          class="input" 
          value={$auth.user?.role || ''} 
          disabled 
        />
      </div>

      <div>
        <label for="createdAt" class="label">Account Created</label>
        <input 
          id="createdAt"
          type="text" 
          class="input" 
          value={$auth.user?.created_at ? new Date($auth.user.created_at).toLocaleDateString() : ''} 
          disabled 
        />
      </div>
    </div>
  </div>

  <div class="card p-6">
    <h2 class="text-xl font-geist font-semibold text-black mb-4">Security</h2>
    <p class="text-sm font-inter text-vercel-gray-600 mb-4">
      Two-factor authentication status
    </p>
    
    {#if $auth.user?.is_2fa_enabled}
      <div class="flex items-center justify-between p-4 bg-green-50 rounded-vercel border border-green-200">
        <div class="flex items-center space-x-3">
          <svg class="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 1.944A11.954 11.954 0 012.166 5C2.056 5.649 2 6.319 2 7c0 5.225 3.34 9.67 8 11.317C14.66 16.67 18 12.225 18 7c0-.682-.057-1.35-.166-2.001A11.954 11.954 0 0110 1.944zM11 14a1 1 0 11-2 0 1 1 0 012 0zm0-7a1 1 0 10-2 0v3a1 1 0 102 0V7z" clip-rule="evenodd" />
          </svg>
          <span class="text-sm font-inter font-medium text-green-900">2FA is enabled</span>
        </div>
        <button class="btn-secondary text-sm">Disable 2FA</button>
      </div>
    {:else}
      <div class="flex items-center justify-between p-4 bg-yellow-50 rounded-vercel border border-yellow-200">
        <div class="flex items-center space-x-3">
          <svg class="w-5 h-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
          </svg>
          <span class="text-sm font-inter font-medium text-yellow-900">2FA is not enabled</span>
        </div>
        <button class="btn-primary text-sm">Enable 2FA</button>
      </div>
    {/if}
  </div>
</div>
