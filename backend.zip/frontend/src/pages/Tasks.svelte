<script>
  // TODO: Implement when Task handler is complete
</script>

<div class="space-y-6">
  <div>
    <h1 class="text-3xl font-geist font-bold text-black">Tasks</h1>
    <p class="mt-1 text-sm font-inter text-vercel-gray-600">
      Manage your internship tasks
    </p>
  </div>

  <div class="card p-12 text-center">
    <svg class="w-24 h-24 mx-auto text-vercel-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
    </svg>
    <h2 class="text-xl font-geist font-semibold text-black mb-2">Tasks Feature Coming Soon</h2>
    <p class="text-sm font-inter text-vercel-gray-600 max-w-md mx-auto">
      This feature will be available once the Task handler is implemented in the backend.
      You'll be able to view, create, and manage your internship tasks here.
    </p>
  </div>
</div>
