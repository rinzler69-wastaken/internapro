<script>
  import { navigate } from 'svelte-routing';
  import { auth, toast } from '../lib/stores';
  import LoadingSpinner from '../components/LoadingSpinner.svelte';

  let email = '';
  let password = '';
  let loading = false;
  let error = '';

  const handleSubmit = async (e) => {
    e.preventDefault();
    error = '';
    loading = true;

    try {
      await auth.login(email, password);
      toast.add('Login successful!', 'success');
      navigate('/dashboard', { replace: true });
    } catch (err) {
      error = err.message || 'Login failed. Please check your credentials.';
      toast.add(error, 'error');
    } finally {
      loading = false;
    }
  };
</script>

<div class="min-h-screen flex items-center justify-center bg-vercel-gray-50 py-12 px-4 sm:px-6 lg:px-8">
  <div class="max-w-md w-full space-y-8 fade-in">
    <!-- Header -->
    <div class="text-center">
      <h1 class="text-4xl font-geist font-bold text-black mb-2">
        Interna
      </h1>
      <p class="text-sm font-inter text-vercel-gray-600">
        Internship Management System
      </p>
    </div>

    <!-- Login card -->
    <div class="card p-8">
      <h2 class="text-2xl font-geist font-semibold text-black mb-6">
        Sign in to your account
      </h2>

      <form on:submit={handleSubmit} class="space-y-5">
        {#if error}
          <div class="bg-red-50 border border-red-200 rounded-vercel p-3">
            <p class="text-sm font-inter text-red-700">{error}</p>
          </div>
        {/if}

        <div>
          <label for="email" class="label">
            Email address
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            bind:value={email}
            class="input"
            placeholder="you@example.com"
            disabled={loading}
          />
        </div>

        <div>
          <label for="password" class="label">
            Password
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            bind:value={password}
            class="input"
            placeholder="••••••••"
            disabled={loading}
          />
        </div>

        <button
          type="submit"
          class="btn-primary w-full flex items-center justify-center"
          disabled={loading}
        >
          {#if loading}
            <LoadingSpinner size="sm" color="white" />
            <span class="ml-2">Signing in...</span>
          {:else}
            Sign in
          {/if}
        </button>
      </form>

      <div class="mt-6 text-center">
        <p class="text-sm font-inter text-vercel-gray-600">
          Don't have an account?
                    <span class="text-black font-medium">
            Contact your administrator
          </span>
        </p>
      </div>
    </div>

    <!-- Footer -->
    <div class="text-center">
      <p class="text-xs font-inter text-vercel-gray-500">
        Powered by INTERNA © 2026
      </p>
    </div>
  </div>
</div>

<style>
  :global(body) {
    background-color: #fafafa;
  }
</style>
