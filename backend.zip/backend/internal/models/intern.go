package models

import (
	"database/sql"
	"time"
)

type Intern struct {
	ID            int64          `json:"id"`
	UserID        int64          `json:"user_id"`
	InstitutionID int64          `json:"institution_id"`
	SupervisorID  int64          `json:"supervisor_id"`
	FullName      string         `json:"full_name"`
	StudentID     string         `json:"student_id"`
	DateOfBirth   sql.NullTime   `json:"date_of_birth"`
	Gender        string         `json:"gender"` // male, female
	Phone         string         `json:"phone"`
	Address       string         `json:"address"`
	StartDate     time.Time      `json:"start_date"`
	EndDate       time.Time      `json:"end_date"`
	Status        string         `json:"status"` // active, completed, terminated
	CreatedAt     time.Time      `json:"created_at"`
	UpdatedAt     time.Time      `json:"updated_at"`
	
	// Related data (for joins)
	User        *User        `json:"user,omitempty"`
	Institution *Institution `json:"institution,omitempty"`
	Supervisor  *Supervisor  `json:"supervisor,omitempty"`
}

type InternWithDetails struct {
	Intern
	SupervisorName   string `json:"supervisor_name"`
	InstitutionName  string `json:"institution_name"`
	Email            string `json:"email"`
}
