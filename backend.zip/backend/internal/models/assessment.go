package models

import (
	"database/sql"
	"time"
)

type Assessment struct {
	ID             int64         `json:"id"`
	InternID       int64         `json:"intern_id"`
	TaskID         sql.NullInt64 `json:"task_id,omitempty"`
	AssessedBy     int64         `json:"assessed_by"` // supervisor_id
	Score          int           `json:"score"`       // 0-100
	Category       string        `json:"category"`    // auto-calculated: very_good, good, not_good, very_bad
	Aspect         string        `json:"aspect"`      // e.g., discipline, work_quality, attitude
	Notes          sql.NullString `json:"notes,omitempty"`
	AssessmentDate time.Time     `json:"assessment_date"`
	CreatedAt      time.Time     `json:"created_at"`
	UpdatedAt      time.Time     `json:"updated_at"`
	
	// Related data
	InternName    string `json:"intern_name,omitempty"`
	AssessorName  string `json:"assessor_name,omitempty"`
	TaskTitle     string `json:"task_title,omitempty"`
}

type CreateAssessmentRequest struct {
	InternID       int64     `json:"intern_id" validate:"required"`
	TaskID         *int64    `json:"task_id,omitempty"`
	Score          int       `json:"score" validate:"required,min=0,max=100"`
	Aspect         string    `json:"aspect" validate:"required,min=3,max=100"`
	Notes          string    `json:"notes,omitempty"`
	AssessmentDate time.Time `json:"assessment_date" validate:"required"`
}

type UpdateAssessmentRequest struct {
	Score          int       `json:"score,omitempty" validate:"omitempty,min=0,max=100"`
	Aspect         string    `json:"aspect,omitempty"`
	Notes          string    `json:"notes,omitempty"`
	AssessmentDate time.Time `json:"assessment_date,omitempty"`
}

// GetCategory returns the category based on score
func (a *Assessment) GetCategory() string {
	if a.Score >= 85 {
		return "very_good"
	} else if a.Score >= 70 {
		return "good"
	} else if a.Score >= 50 {
		return "not_good"
	}
	return "very_bad"
}

// GetCategoryIndo returns Indonesian translation
func (a *Assessment) GetCategoryIndo() string {
	switch a.Category {
	case "very_good":
		return "Sangat Baik"
	case "good":
		return "Baik"
	case "not_good":
		return "Tidak Baik"
	case "very_bad":
		return "Sangat Tidak Baik"
	default:
		return ""
	}
}
