package models

import (
	"database/sql"
	"time"
)

type Task struct {
	ID            int64        `json:"id"`
	InternID      int64        `json:"intern_id"`
	AssignedBy    int64        `json:"assigned_by"` // supervisor_id
	Title         string       `json:"title"`
	Description   string       `json:"description"`
	StartDate     time.Time    `json:"start_date"`
	TargetDate    time.Time    `json:"target_date"`
	CompletedDate sql.NullTime `json:"completed_date,omitempty"`
	Status        string       `json:"status"` // pending, in_progress, completed, overdue
	CreatedAt     time.Time    `json:"created_at"`
	UpdatedAt     time.Time    `json:"updated_at"`
	
	// Related data
	Attachments []TaskAttachment `json:"attachments,omitempty"`
	InternName  string           `json:"intern_name,omitempty"`
	AssignedByName string        `json:"assigned_by_name,omitempty"`
}

type TaskAttachment struct {
	ID         int64     `json:"id"`
	TaskID     int64     `json:"task_id"`
	FileName   string    `json:"file_name"`
	FilePath   string    `json:"file_path"`
	FileType   string    `json:"file_type"` // jpg, jpeg, png, pdf
	FileSize   int64     `json:"file_size"`
	UploadedAt time.Time `json:"uploaded_at"`
}

type CreateTaskRequest struct {
	InternID    int64     `json:"intern_id" validate:"required"`
	Title       string    `json:"title" validate:"required,min=3,max=255"`
	Description string    `json:"description" validate:"required"`
	StartDate   time.Time `json:"start_date" validate:"required"`
	TargetDate  time.Time `json:"target_date" validate:"required"`
}

type UpdateTaskRequest struct {
	Title         string       `json:"title,omitempty"`
	Description   string       `json:"description,omitempty"`
	StartDate     *time.Time   `json:"start_date,omitempty"`
	TargetDate    *time.Time   `json:"target_date,omitempty"`
	CompletedDate *time.Time   `json:"completed_date,omitempty"`
	Status        string       `json:"status,omitempty"`
}
