package models

import (
	"database/sql"
	"time"
)

type Attendance struct {
	ID               int64            `json:"id"`
	InternID         int64            `json:"intern_id"`
	Date             time.Time        `json:"date"`
	CheckInTime      sql.NullTime     `json:"check_in_time,omitempty"`
	CheckInLatitude  sql.NullFloat64  `json:"check_in_latitude,omitempty"`
	CheckInLongitude sql.NullFloat64  `json:"check_in_longitude,omitempty"`
	CheckOutTime     sql.NullTime     `json:"check_out_time,omitempty"`
	CheckOutLatitude sql.NullFloat64  `json:"check_out_latitude,omitempty"`
	CheckOutLongitude sql.NullFloat64 `json:"check_out_longitude,omitempty"`
	Status           string           `json:"status"` // present, late, absent, on_leave, excused
	LateReason       sql.NullString   `json:"late_reason,omitempty"`
	CreatedAt        time.Time        `json:"created_at"`
	UpdatedAt        time.Time        `json:"updated_at"`
	
	// Related data
	InternName string `json:"intern_name,omitempty"`
}

type CheckInRequest struct {
	Latitude  float64 `json:"latitude" validate:"required,latitude"`
	Longitude float64 `json:"longitude" validate:"required,longitude"`
}

type CheckOutRequest struct {
	Latitude  float64 `json:"latitude" validate:"required,latitude"`
	Longitude float64 `json:"longitude" validate:"required,longitude"`
}

type LateCheckInRequest struct {
	Latitude  float64 `json:"latitude" validate:"required,latitude"`
	Longitude float64 `json:"longitude" validate:"required,longitude"`
	Reason    string  `json:"reason" validate:"required,min=10"`
}

type OfficeSettings struct {
	ID                   int64   `json:"id"`
	Latitude             float64 `json:"latitude"`
	Longitude            float64 `json:"longitude"`
	RadiusMeters         int     `json:"radius_meters"`
	CheckInTime          string  `json:"check_in_time"`
	CheckOutTime         string  `json:"check_out_time"`
	LateToleranceMinutes int     `json:"late_tolerance_minutes"`
	CreatedAt            time.Time `json:"created_at"`
	UpdatedAt            time.Time `json:"updated_at"`
}
