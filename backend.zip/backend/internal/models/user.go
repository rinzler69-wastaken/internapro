package models

import (
	"database/sql"
	"time"
)

type User struct {
	ID           int64          `json:"id"`
	Email        string         `json:"email"`
	PasswordHash string         `json:"-"` // Never expose password hash
	Role         string         `json:"role"` // admin, supervisor, intern
	TOTPSecret   sql.NullString `json:"-"`    // Never expose TOTP secret
	Is2FAEnabled bool           `json:"is_2fa_enabled"`
	CreatedAt    time.Time      `json:"created_at"`
	UpdatedAt    time.Time      `json:"updated_at"`
}

type Supervisor struct {
	ID        int64     `json:"id"`
	UserID    int64     `json:"user_id"`
	FullName  string    `json:"full_name"`
	NIP       string    `json:"nip"`
	Phone     string    `json:"phone"`
	Position  string    `json:"position"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type Institution struct {
	ID        int64     `json:"id"`
	Name      string    `json:"name"`
	Address   string    `json:"address"`
	Phone     string    `json:"phone"`
	Email     string    `json:"email"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}
