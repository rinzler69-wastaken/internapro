package models

import (
	"database/sql"
	"time"
)

type LeaveRequest struct {
	ID             int64          `json:"id"`
	InternID       int64          `json:"intern_id"`
	LeaveType      string         `json:"leave_type"` // sick, permission, other
	StartDate      time.Time      `json:"start_date"`
	EndDate        time.Time      `json:"end_date"`
	Reason         string         `json:"reason"`
	AttachmentPath sql.NullString `json:"attachment_path,omitempty"`
	Status         string         `json:"status"` // pending, approved, rejected
	ApprovedBy     sql.NullInt64  `json:"approved_by,omitempty"`
	ApprovedAt     sql.NullTime   `json:"approved_at,omitempty"`
	CreatedAt      time.Time      `json:"created_at"`
	UpdatedAt      time.Time      `json:"updated_at"`
	
	// Related data
	InternName     string `json:"intern_name,omitempty"`
	ApproverName   string `json:"approver_name,omitempty"`
}

type CreateLeaveRequest struct {
	LeaveType string    `json:"leave_type" validate:"required,oneof=sick permission other"`
	StartDate time.Time `json:"start_date" validate:"required"`
	EndDate   time.Time `json:"end_date" validate:"required"`
	Reason    string    `json:"reason" validate:"required,min=10"`
}

type ApproveLeaveRequest struct {
	Status string `json:"status" validate:"required,oneof=approved rejected"`
}
