package routes

import (
	"database/sql"
	"net/http"

	"dsi_interna_sys/internal/handlers"
	"dsi_interna_sys/internal/middleware"

	"github.com/gorilla/mux"
)

// SetupRoutes configures all application routes
func SetupRoutes(router *mux.Router, db *sql.DB) {
	// Initialize handlers
	authHandler := handlers.NewAuthHandler(db)
	internHandler := handlers.NewInternHandler(db)
	taskHandler := handlers.NewTaskHandler(db)
	attendanceHandler := handlers.NewAttendanceHandler(db)
	leaveHandler := handlers.NewLeaveHandler(db)
	assessmentHandler := handlers.NewAssessmentHandler(db)
	reportHandler := handlers.NewReportHandler(db)
	analyticsHandler := handlers.NewAnalyticsHandler(db)

	// API routes
	api := router.PathPrefix("/api").Subrouter()

	// Public routes (no authentication required)
	api.HandleFunc("/health", healthCheck).Methods("GET")
	api.HandleFunc("/auth/login", authHandler.Login).Methods("POST")

	// Protected routes (authentication required)
	protected := api.PathPrefix("").Subrouter()
	protected.Use(middleware.AuthMiddleware)

	// Admin routes
	admin := protected.PathPrefix("").Subrouter()
	admin.Use(middleware.RequireRole("admin"))
	admin.HandleFunc("/auth/register", authHandler.Register).Methods("POST")

	// Authentication & 2FA
	protected.HandleFunc("/auth/me", authHandler.GetCurrentUser).Methods("GET")
	protected.HandleFunc("/auth/2fa/setup", authHandler.Setup2FA).Methods("POST")
	protected.HandleFunc("/auth/2fa/verify", authHandler.Verify2FA).Methods("POST")
	protected.HandleFunc("/auth/2fa/disable", authHandler.Disable2FA).Methods("POST")
	protected.HandleFunc("/auth/logout", authHandler.Logout).Methods("POST")

	// Interns
	protected.HandleFunc("/interns", internHandler.GetAll).Methods("GET")
	protected.HandleFunc("/interns/{id}", internHandler.GetByID).Methods("GET")
	protected.HandleFunc("/interns", internHandler.Create).Methods("POST")
	protected.HandleFunc("/interns/{id}", internHandler.Update).Methods("PUT")
	protected.HandleFunc("/interns/{id}", internHandler.Delete).Methods("DELETE")

	// Tasks
	protected.HandleFunc("/tasks", taskHandler.GetAll).Methods("GET")
	protected.HandleFunc("/tasks/{id}", taskHandler.GetByID).Methods("GET")
	protected.HandleFunc("/tasks/intern/{id}", taskHandler.GetByInternID).Methods("GET")
	protected.HandleFunc("/tasks", taskHandler.Create).Methods("POST")
	protected.HandleFunc("/tasks/{id}", taskHandler.Update).Methods("PUT")
	protected.HandleFunc("/tasks/{id}", taskHandler.Delete).Methods("DELETE")
	protected.HandleFunc("/tasks/{id}/attachments", taskHandler.UploadAttachment).Methods("POST")
	protected.HandleFunc("/tasks/{id}/complete", taskHandler.MarkComplete).Methods("POST")

	// Attendance
	protected.HandleFunc("/attendance", attendanceHandler.GetAll).Methods("GET")
	protected.HandleFunc("/attendance/{id}", attendanceHandler.GetByID).Methods("GET")
	protected.HandleFunc("/attendance/intern/{id}", attendanceHandler.GetByInternID).Methods("GET")
	protected.HandleFunc("/attendance/checkin", attendanceHandler.CheckIn).Methods("POST")
	protected.HandleFunc("/attendance/checkout", attendanceHandler.CheckOut).Methods("POST")
	protected.HandleFunc("/attendance/today", attendanceHandler.GetToday).Methods("GET")

	// Leave Requests
	protected.HandleFunc("/leaves", leaveHandler.GetAll).Methods("GET")
	protected.HandleFunc("/leaves/{id}", leaveHandler.GetByID).Methods("GET")
	protected.HandleFunc("/leaves/intern/{id}", leaveHandler.GetByInternID).Methods("GET")
	protected.HandleFunc("/leaves", leaveHandler.Create).Methods("POST")
	protected.HandleFunc("/leaves/{id}", leaveHandler.Update).Methods("PUT")
	protected.HandleFunc("/leaves/{id}/approve", leaveHandler.Approve).Methods("POST")
	protected.HandleFunc("/leaves/{id}/reject", leaveHandler.Reject).Methods("POST")
	protected.HandleFunc("/leaves/{id}/attachment", leaveHandler.UploadAttachment).Methods("POST")

	// Assessments
	protected.HandleFunc("/assessments", assessmentHandler.GetAll).Methods("GET")
	protected.HandleFunc("/assessments/{id}", assessmentHandler.GetByID).Methods("GET")
	protected.HandleFunc("/assessments/intern/{id}", assessmentHandler.GetByInternID).Methods("GET")
	protected.HandleFunc("/assessments", assessmentHandler.Create).Methods("POST")
	protected.HandleFunc("/assessments/{id}", assessmentHandler.Update).Methods("PUT")
	protected.HandleFunc("/assessments/{id}", assessmentHandler.Delete).Methods("DELETE")

	// Reports
	protected.HandleFunc("/reports/intern/{id}", reportHandler.GetInternReport).Methods("GET")
	protected.HandleFunc("/reports/attendance/{id}", reportHandler.GetAttendanceReport).Methods("GET")
	protected.HandleFunc("/reports/assessments/{id}", reportHandler.GetAssessmentReport).Methods("GET")
	protected.HandleFunc("/reports/certificate/{id}", reportHandler.GetCertificate).Methods("GET")
	protected.HandleFunc("/reports/certificate/{id}/generate", reportHandler.GenerateCertificate).Methods("POST")

	// Analytics & Performance Trends
	analytics := protected.PathPrefix("/analytics").Subrouter()
	analytics.Use(middleware.RequireRole("admin", "supervisor", "intern"))
	analytics.HandleFunc("/trends/weekly/{id:[0-9]+}", analyticsHandler.GetWeeklyTrends).Methods("GET")
	analytics.HandleFunc("/patterns/checkin/{id:[0-9]+}", analyticsHandler.GetCheckInPatterns).Methods("GET")
	analytics.HandleFunc("/insights/{id:[0-9]+}", analyticsHandler.GetPerformanceInsights).Methods("GET")

	// Static file serving for uploads
	router.PathPrefix("/uploads/").Handler(
		http.StripPrefix("/uploads/",
			middleware.AuthMiddleware(
				http.FileServer(http.Dir("./uploads")),
			),
		),
	)

	// Serve frontend (if needed)
	// router.PathPrefix("/").Handler(http.FileServer(http.Dir("./web")))
}

// healthCheck is a simple health check endpoint
func healthCheck(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"status":"ok","message":"INTERNA API is running"}`))
}
