package config

import (
	"log"
	"os"
	"strconv"
	"time"

	"github.com/joho/godotenv"
)

type Config struct {
	Server   ServerConfig
	Database DatabaseConfig
	JWT      JWTConfig
	Upload   UploadConfig
	Office   OfficeConfig
	App      AppConfig
}

type ServerConfig struct {
	Port string
	Host string
}

type DatabaseConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	DBName   string
}

type JWTConfig struct {
	Secret string
	Expiry time.Duration
}

type UploadConfig struct {
	Dir         string
	MaxSize     int64
	AllowedExts []string
}

type OfficeConfig struct {
	Latitude             float64
	Longitude            float64
	Radius               float64
	CheckInTime          string
	CheckOutTime         string
	LateToleranceMinutes int
}

type AppConfig struct {
	Name string
	Env  string
}

var Loaded *Config

// Load loads configuration from environment variables
func Load() (*Config, error) {
	// Load .env file if it exists
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using system environment variables")
	}

	// Parse JWT expiry
	jwtExpiry, err := time.ParseDuration(getEnv("JWT_EXPIRY", "24h"))
	if err != nil {
		jwtExpiry = 24 * time.Hour
	}

	// Parse max upload size
	maxUploadSize, err := strconv.ParseInt(getEnv("MAX_UPLOAD_SIZE", "5242880"), 10, 64)
	if err != nil {
		maxUploadSize = 5242880 // 5MB default
	}

	// Parse office location
	latitude, err := strconv.ParseFloat(getEnv("OFFICE_LATITUDE", "-6.9932200"), 64)
	if err != nil {
		latitude = -6.9932200
	}

	longitude, err := strconv.ParseFloat(getEnv("OFFICE_LONGITUDE", "110.4207900"), 64)
	if err != nil {
		longitude = 110.4207900
	}

	radius, err := strconv.ParseFloat(getEnv("OFFICE_RADIUS", "1000"), 64)
	if err != nil {
		radius = 1000
	}

	lateTolerance, err := strconv.Atoi(getEnv("LATE_TOLERANCE_MINUTES", "15"))
	if err != nil {
		lateTolerance = 15
	}

	config := &Config{
		Server: ServerConfig{
			Port: getEnv("SERVER_PORT", "8080"),
			Host: getEnv("SERVER_HOST", "localhost"),
		},
		Database: DatabaseConfig{
			Host:     getEnv("DB_HOST", "localhost"),
			Port:     getEnv("DB_PORT", "3306"),
			User:     getEnv("DB_USER", "root"),
			Password: getEnv("DB_PASSWORD", ""),
			DBName:   getEnv("DB_NAME", "interna_db"),
		},
		JWT: JWTConfig{
			Secret: getEnv("JWT_SECRET", "change-this-secret-key"),
			Expiry: jwtExpiry,
		},
		Upload: UploadConfig{
			Dir:         getEnv("UPLOAD_DIR", "./uploads"),
			MaxSize:     maxUploadSize,
			AllowedExts: []string{".jpg", ".jpeg", ".png", ".pdf"},
		},
		Office: OfficeConfig{
			Latitude:             latitude,
			Longitude:            longitude,
			Radius:               radius,
			CheckInTime:          getEnv("CHECK_IN_TIME", "08:00:00"),
			CheckOutTime:         getEnv("CHECK_OUT_TIME", "17:00:00"),
			LateToleranceMinutes: lateTolerance,
		},
		App: AppConfig{
			Name: getEnv("APP_NAME", "INTERNA"),
			Env:  getEnv("APP_ENV", "development"),
		},
	}

	Loaded = config
	return config, nil
}

// getEnv gets environment variable with default fallback
func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}
