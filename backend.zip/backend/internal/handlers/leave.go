package handlers

import (
	"database/sql"
	"net/http"

	"dsi_interna_sys/internal/utils"
)

type LeaveHandler struct {
	db *sql.DB
}

func NewLeaveHandler(db *sql.DB) *LeaveHandler {
	return &LeaveHandler{db: db}
}

func (h *LeaveHandler) GetAll(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - List all leave requests
	utils.RespondSuccess(w, "Get all leaves - Not implemented yet", nil)
}

func (h *LeaveHandler) GetByID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get leave request by ID
	utils.RespondSuccess(w, "Get leave by ID - Not implemented yet", nil)
}

func (h *LeaveHandler) GetByInternID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get leave requests for specific intern
	utils.RespondSuccess(w, "Get leaves by intern ID - Not implemented yet", nil)
}

func (h *LeaveHandler) Create(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Create leave request
	utils.RespondSuccess(w, "Create leave - Not implemented yet", nil)
}

func (h *LeaveHandler) Update(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Update leave request
	utils.RespondSuccess(w, "Update leave - Not implemented yet", nil)
}

func (h *LeaveHandler) Approve(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Approve leave request (supervisor only)
	utils.RespondSuccess(w, "Approve leave - Not implemented yet", nil)
}

func (h *LeaveHandler) Reject(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Reject leave request (supervisor only)
	utils.RespondSuccess(w, "Reject leave - Not implemented yet", nil)
}

func (h *LeaveHandler) UploadAttachment(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Upload leave letter attachment
	utils.RespondSuccess(w, "Upload leave attachment - Not implemented yet", nil)
}
