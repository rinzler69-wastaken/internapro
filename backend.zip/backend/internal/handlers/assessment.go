package handlers

import (
	"database/sql"
	"net/http"

	"dsi_interna_sys/internal/utils"
)

type AssessmentHandler struct {
	db *sql.DB
}

func NewAssessmentHandler(db *sql.DB) *AssessmentHandler {
	return &AssessmentHandler{db: db}
}

func (h *AssessmentHandler) GetAll(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - List all assessments
	utils.RespondSuccess(w, "Get all assessments - Not implemented yet", nil)
}

func (h *AssessmentHandler) GetByID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get assessment by ID
	utils.RespondSuccess(w, "Get assessment by ID - Not implemented yet", nil)
}

func (h *AssessmentHandler) GetByInternID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get assessments for specific intern
	utils.RespondSuccess(w, "Get assessments by intern ID - Not implemented yet", nil)
}

func (h *AssessmentHandler) Create(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Create assessment (supervisor only)
	// Score 0-100
	// Category auto-calculated:
	//   85-100: very_good
	//   70-84:  good
	//   50-69:  not_good
	//   0-49:   very_bad
	utils.RespondSuccess(w, "Create assessment - Not implemented yet", nil)
}

func (h *AssessmentHandler) Update(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Update assessment
	utils.RespondSuccess(w, "Update assessment - Not implemented yet", nil)
}

func (h *AssessmentHandler) Delete(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Delete assessment
	utils.RespondSuccess(w, "Delete assessment - Not implemented yet", nil)
}
