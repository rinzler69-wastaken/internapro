package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"time"

	"dsi_interna_sys/internal/config"
	"dsi_interna_sys/internal/middleware"
	"dsi_interna_sys/internal/models"
	"dsi_interna_sys/internal/utils"

	"github.com/golang-jwt/jwt/v5"
	"github.com/pquerna/otp/totp"
	"golang.org/x/crypto/bcrypt"
)

type AuthHandler struct {
	db *sql.DB
}

func NewAuthHandler(db *sql.DB) *AuthHandler {
	return &AuthHandler{db: db}
}

// RegisterRequest represents registration request
type RegisterRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	Role     string `json:"role,omitempty"` // admin, supervisor, intern
	FullName string `json:"full_name"`

	// Optional fields for intern
	StudentID     string `json:"student_id,omitempty"`
	InstitutionID int64  `json:"institution_id,omitempty"`
	SupervisorID  int64  `json:"supervisor_id,omitempty"`
	StartDate     string `json:"start_date,omitempty"`
	EndDate       string `json:"end_date,omitempty"`

	// Optional fields for supervisor
	NIP      string `json:"nip,omitempty"`
	Position string `json:"position,omitempty"`
}

// LoginRequest represents login request
type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
	TOTPCode string `json:"totp_code,omitempty"` // Required if 2FA enabled
}

// LoginResponse represents login response
type LoginResponse struct {
	Token      string      `json:"token"`
	User       models.User `json:"user"`
	Require2FA bool        `json:"require_2fa"`
}

// Setup2FAResponse represents 2FA setup response
type Setup2FAResponse struct {
	Secret string `json:"secret"`
	QRCode string `json:"qr_code"`
}

// Verify2FARequest represents 2FA verification request
type Verify2FARequest struct {
	Code string `json:"code"`
}

// Register creates a new user
func (h *AuthHandler) Register(w http.ResponseWriter, r *http.Request) {
	var req RegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.RespondBadRequest(w, "Invalid request body")
		return
	}

	// Validate input
	if req.Email == "" || req.Password == "" || req.Role == "" || req.FullName == "" {
		utils.RespondBadRequest(w, "Missing required fields")
		return
	}

	// Validate role
	if req.Role != "admin" && req.Role != "supervisor" && req.Role != "intern" {
		utils.RespondBadRequest(w, "Invalid role. Must be admin, supervisor, or intern")
		return
	}

	// Validate password length
	if len(req.Password) < 6 {
		utils.RespondBadRequest(w, "Password must be at least 6 characters")
		return
	}

	// Hash password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		utils.RespondInternalError(w, "Failed to hash password")
		return
	}

	// Start transaction
	tx, err := h.db.Begin()
	if err != nil {
		utils.RespondInternalError(w, "Failed to start transaction")
		return
	}
	defer tx.Rollback()

	// Insert user
	result, err := tx.Exec(
		"INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)",
		req.Email, string(hashedPassword), req.Role,
	)
	if err != nil {
		utils.RespondBadRequest(w, "Email already exists")
		return
	}

	userID, _ := result.LastInsertId()

	// Create role-specific record
	switch req.Role {
	case "supervisor":
		_, err = tx.Exec(
			"INSERT INTO supervisors (user_id, full_name, nip, position) VALUES (?, ?, ?, ?)",
			userID, req.FullName, req.NIP, req.Position,
		)
	case "intern":
		if req.InstitutionID == 0 || req.SupervisorID == 0 {
			utils.RespondBadRequest(w, "Institution and supervisor are required for interns")
			return
		}

		startDate := time.Now()
		endDate := time.Now().AddDate(0, 3, 0) // Default 3 months

		if req.StartDate != "" {
			startDate, _ = time.Parse("2006-01-02", req.StartDate)
		}
		if req.EndDate != "" {
			endDate, _ = time.Parse("2006-01-02", req.EndDate)
		}

		_, err = tx.Exec(
			`INSERT INTO interns (user_id, institution_id, supervisor_id, full_name, student_id, start_date, end_date, status) 
			 VALUES (?, ?, ?, ?, ?, ?, ?, 'active')`,
			userID, req.InstitutionID, req.SupervisorID, req.FullName, req.StudentID, startDate, endDate,
		)
	}

	if err != nil {
		utils.RespondInternalError(w, "Failed to create user profile")
		return
	}

	// Commit transaction
	if err := tx.Commit(); err != nil {
		utils.RespondInternalError(w, "Failed to commit transaction")
		return
	}

	utils.RespondCreated(w, "User registered successfully", map[string]interface{}{
		"user_id": userID,
		"email":   req.Email,
		"role":    req.Role,
	})
}

// Login authenticates user and returns JWT token
func (h *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	var req LoginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.RespondBadRequest(w, "Invalid request body")
		return
	}

	// Find user
	var user models.User
	err := h.db.QueryRow(
		"SELECT id, email, password_hash, role, totp_secret, is_2fa_enabled FROM users WHERE email = ?",
		req.Email,
	).Scan(&user.ID, &user.Email, &user.PasswordHash, &user.Role, &user.TOTPSecret, &user.Is2FAEnabled)

	if err != nil {
		utils.RespondUnauthorized(w, "Invalid email or password")
		return
	}

	// Verify password
	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
		utils.RespondUnauthorized(w, "Invalid email or password")
		return
	}

	// Check 2FA
	if user.Is2FAEnabled {
		if req.TOTPCode == "" {
			utils.RespondJSON(w, http.StatusOK, LoginResponse{
				Require2FA: true,
			})
			return
		}

		// Verify TOTP code
		if !user.TOTPSecret.Valid {
			utils.RespondUnauthorized(w, "2FA is enabled but no secret is configured")
			return
		}
		valid := totp.Validate(req.TOTPCode, user.TOTPSecret.String)
		if !valid {
			utils.RespondUnauthorized(w, "Invalid 2FA code")
			return
		}
	}

	// Generate JWT token
	token, err := h.generateToken(&user)
	if err != nil {
		utils.RespondInternalError(w, "Failed to generate token")
		return
	}

	utils.RespondSuccess(w, "Login successful", LoginResponse{
		Token:      token,
		User:       user,
		Require2FA: false,
	})
}

// Setup2FA generates TOTP secret and QR code
func (h *AuthHandler) Setup2FA(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	// Generate TOTP secret
	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      "INTERNA",
		AccountName: claims.Email,
	})
	if err != nil {
		utils.RespondInternalError(w, "Failed to generate 2FA secret")
		return
	}

	// Save secret to database
	_, err = h.db.Exec(
		"UPDATE users SET totp_secret = ? WHERE id = ?",
		key.Secret(), claims.UserID,
	)
	if err != nil {
		utils.RespondInternalError(w, "Failed to save 2FA secret")
		return
	}

	utils.RespondSuccess(w, "2FA setup initiated. Scan the QR code with Google Authenticator", Setup2FAResponse{
		Secret: key.Secret(),
		QRCode: key.URL(),
	})
}

// Verify2FA verifies and enables 2FA
func (h *AuthHandler) Verify2FA(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	var req Verify2FARequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.RespondBadRequest(w, "Invalid request body")
		return
	}

	// Get user's TOTP secret
	var secret string
	err := h.db.QueryRow("SELECT totp_secret FROM users WHERE id = ?", claims.UserID).Scan(&secret)
	if err != nil {
		utils.RespondInternalError(w, "Failed to retrieve 2FA secret")
		return
	}

	// Verify code
	valid := totp.Validate(req.Code, secret)
	if !valid {
		utils.RespondBadRequest(w, "Invalid 2FA code")
		return
	}

	// Enable 2FA
	_, err = h.db.Exec("UPDATE users SET is_2fa_enabled = TRUE WHERE id = ?", claims.UserID)
	if err != nil {
		utils.RespondInternalError(w, "Failed to enable 2FA")
		return
	}

	utils.RespondSuccess(w, "2FA enabled successfully", nil)
}

// Disable2FA disables 2FA for user
func (h *AuthHandler) Disable2FA(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	_, err := h.db.Exec(
		"UPDATE users SET is_2fa_enabled = FALSE, totp_secret = NULL WHERE id = ?",
		claims.UserID,
	)
	if err != nil {
		utils.RespondInternalError(w, "Failed to disable 2FA")
		return
	}

	utils.RespondSuccess(w, "2FA disabled successfully", nil)
}

// GetCurrentUser returns current user information
func (h *AuthHandler) GetCurrentUser(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	var user models.User
	err := h.db.QueryRow(
		"SELECT id, email, role, is_2fa_enabled, created_at FROM users WHERE id = ?",
		claims.UserID,
	).Scan(&user.ID, &user.Email, &user.Role, &user.Is2FAEnabled, &user.CreatedAt)

	if err != nil {
		utils.RespondNotFound(w, "User not found")
		return
	}

	utils.RespondSuccess(w, "User retrieved successfully", user)
}

// Logout handles logout (mainly client-side token removal)
func (h *AuthHandler) Logout(w http.ResponseWriter, r *http.Request) {
	// In a stateless JWT system, logout is mainly handled client-side
	// You could implement token blacklisting here if needed
	utils.RespondSuccess(w, "Logged out successfully", nil)
}

// generateToken creates a new JWT token
func (h *AuthHandler) generateToken(user *models.User) (string, error) {
	cfg := config.Loaded

	claims := middleware.Claims{
		UserID: user.ID,
		Email:  user.Email,
		Role:   user.Role,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(cfg.JWT.Expiry)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(cfg.JWT.Secret))
}
