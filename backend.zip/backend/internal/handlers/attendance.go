package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"strconv"
	"time"

	"dsi_interna_sys/internal/config"
	"dsi_interna_sys/internal/middleware"
	"dsi_interna_sys/internal/models"
	"dsi_interna_sys/internal/utils"

	"github.com/gorilla/mux"
)

type AttendanceHandler struct {
	db *sql.DB
}

func NewAttendanceHandler(db *sql.DB) *AttendanceHandler {
	return &AttendanceHandler{db: db}
}

// CheckIn handles attendance check-in with geolocation validation
func (h *AttendanceHandler) CheckIn(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	// Only interns can check in
	if claims.Role != "intern" {
		utils.RespondForbidden(w, "Only interns can check in")
		return
	}

	var req models.CheckInRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.RespondBadRequest(w, "Invalid request body")
		return
	}

	// Validate coordinates
	if !utils.ValidateCoordinates(req.Latitude, req.Longitude) {
		utils.RespondBadRequest(w, "Invalid coordinates")
		return
	}

	// Get intern ID
	var internID int64
	err := h.db.QueryRow("SELECT id FROM interns WHERE user_id = ?", claims.UserID).Scan(&internID)
	if err != nil {
		utils.RespondNotFound(w, "Intern not found")
		return
	}

	// Get office settings
	cfg := config.Loaded
	officeSettings := models.OfficeSettings{
		Latitude:             cfg.Office.Latitude,
		Longitude:            cfg.Office.Longitude,
		RadiusMeters:         int(cfg.Office.Radius),
		CheckInTime:          cfg.Office.CheckInTime,
		LateToleranceMinutes: cfg.Office.LateToleranceMinutes,
	}

	// Check if within office radius
	distance := utils.HaversineDistance(
		officeSettings.Latitude,
		officeSettings.Longitude,
		req.Latitude,
		req.Longitude,
	)

	if distance > float64(officeSettings.RadiusMeters) {
		utils.RespondBadRequest(w, "You are not within the office radius. Distance: "+strconv.FormatFloat(distance, 'f', 2, 64)+" meters")
		return
	}

	// Check if already checked in today
	today := time.Now().Format("2006-01-02")
	var existingID int64
	err = h.db.QueryRow(
		"SELECT id FROM attendances WHERE intern_id = ? AND date = ?",
		internID, today,
	).Scan(&existingID)

	if err == nil {
		utils.RespondBadRequest(w, "Already checked in today")
		return
	}

	// Check time
	now := time.Now()
	checkInTime, _ := time.Parse("15:04:05", officeSettings.CheckInTime)
	checkInLimit := time.Date(now.Year(), now.Month(), now.Day(), checkInTime.Hour(), checkInTime.Minute(), checkInTime.Second(), 0, now.Location())
	checkInLimit = checkInLimit.Add(time.Duration(officeSettings.LateToleranceMinutes) * time.Minute)

	status := "present"
	var lateReason sql.NullString

	if now.After(checkInLimit) {
		status = "late"
		// For late check-in, we should require a reason
		// This should be sent in the request as well
		var lateReq struct {
			Latitude  float64 `json:"latitude"`
			Longitude float64 `json:"longitude"`
			Reason    string  `json:"reason"`
		}

		// Re-decode to get reason
		r.Body.Close()
		if err := utils.ParseJSON(r, &lateReq); err == nil && lateReq.Reason != "" {
			lateReason = sql.NullString{String: lateReq.Reason, Valid: true}
		}
	}

	// Create attendance record
	result, err := h.db.Exec(
		`INSERT INTO attendances (intern_id, date, check_in_time, check_in_latitude, check_in_longitude, status, late_reason)
		 VALUES (?, ?, ?, ?, ?, ?, ?)`,
		internID, today, now, req.Latitude, req.Longitude, status, lateReason,
	)

	if err != nil {
		utils.RespondInternalError(w, "Failed to create attendance record")
		return
	}

	attendanceID, _ := result.LastInsertId()

	utils.RespondSuccess(w, "Check-in successful", map[string]interface{}{
		"attendance_id": attendanceID,
		"status":        status,
		"check_in_time": now,
		"distance":      distance,
	})
}

// CheckOut handles attendance check-out
func (h *AttendanceHandler) CheckOut(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	if claims.Role != "intern" {
		utils.RespondForbidden(w, "Only interns can check out")
		return
	}

	var req models.CheckOutRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.RespondBadRequest(w, "Invalid request body")
		return
	}

	// Validate coordinates
	if !utils.ValidateCoordinates(req.Latitude, req.Longitude) {
		utils.RespondBadRequest(w, "Invalid coordinates")
		return
	}

	// Get intern ID
	var internID int64
	err := h.db.QueryRow("SELECT id FROM interns WHERE user_id = ?", claims.UserID).Scan(&internID)
	if err != nil {
		utils.RespondNotFound(w, "Intern not found")
		return
	}

	// Get today's attendance
	today := time.Now().Format("2006-01-02")
	var attendance models.Attendance
	err = h.db.QueryRow(
		`SELECT id, check_in_time, check_out_time FROM attendances 
		 WHERE intern_id = ? AND date = ?`,
		internID, today,
	).Scan(&attendance.ID, &attendance.CheckInTime, &attendance.CheckOutTime)

	if err != nil {
		utils.RespondBadRequest(w, "No check-in record found for today")
		return
	}

	if attendance.CheckOutTime.Valid {
		utils.RespondBadRequest(w, "Already checked out today")
		return
	}

	// Check if within office radius
	cfg := config.Loaded
	distance := utils.HaversineDistance(
		cfg.Office.Latitude,
		cfg.Office.Longitude,
		req.Latitude,
		req.Longitude,
	)

	if distance > cfg.Office.Radius {
		utils.RespondBadRequest(w, "You are not within the office radius")
		return
	}

	// Update attendance record
	now := time.Now()
	_, err = h.db.Exec(
		`UPDATE attendances SET check_out_time = ?, check_out_latitude = ?, check_out_longitude = ?
		 WHERE id = ?`,
		now, req.Latitude, req.Longitude, attendance.ID,
	)

	if err != nil {
		utils.RespondInternalError(w, "Failed to update attendance record")
		return
	}

	utils.RespondSuccess(w, "Check-out successful", map[string]interface{}{
		"attendance_id":  attendance.ID,
		"check_out_time": now,
		"distance":       distance,
	})
}

// GetAll retrieves all attendance records (admin/supervisor)
func (h *AttendanceHandler) GetAll(w http.ResponseWriter, r *http.Request) {
	_, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	// Parse pagination
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if page < 1 {
		page = 1
	}
	if limit < 1 {
		limit = 10
	}
	offset := (page - 1) * limit

	// Query attendances with intern names
	query := `
		SELECT a.id, a.intern_id, a.date, a.check_in_time, a.check_out_time, 
		       a.status, a.late_reason, i.full_name
		FROM attendances a
		JOIN interns i ON a.intern_id = i.id
		ORDER BY a.date DESC, a.check_in_time DESC
		LIMIT ? OFFSET ?
	`

	rows, err := h.db.Query(query, limit, offset)
	if err != nil {
		utils.RespondInternalError(w, "Database error")
		return
	}
	defer rows.Close()

	var attendances []models.Attendance
	for rows.Next() {
		var a models.Attendance
		err := rows.Scan(
			&a.ID, &a.InternID, &a.Date, &a.CheckInTime, &a.CheckOutTime,
			&a.Status, &a.LateReason, &a.InternName,
		)
		if err != nil {
			continue
		}
		attendances = append(attendances, a)
	}

	// Get total count
	var total int64
	h.db.QueryRow("SELECT COUNT(*) FROM attendances").Scan(&total)

	pagination := utils.CalculatePagination(page, limit, total)
	utils.RespondPaginated(w, attendances, pagination)
}

// GetByID retrieves a specific attendance record
func (h *AttendanceHandler) GetByID(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, err := strconv.ParseInt(vars["id"], 10, 64)
	if err != nil {
		utils.RespondBadRequest(w, "Invalid attendance ID")
		return
	}

	var attendance models.Attendance
	err = h.db.QueryRow(
		`SELECT a.id, a.intern_id, a.date, a.check_in_time, a.check_in_latitude, a.check_in_longitude,
		        a.check_out_time, a.check_out_latitude, a.check_out_longitude, a.status, a.late_reason,
		        i.full_name
		 FROM attendances a
		 JOIN interns i ON a.intern_id = i.id
		 WHERE a.id = ?`,
		id,
	).Scan(
		&attendance.ID, &attendance.InternID, &attendance.Date,
		&attendance.CheckInTime, &attendance.CheckInLatitude, &attendance.CheckInLongitude,
		&attendance.CheckOutTime, &attendance.CheckOutLatitude, &attendance.CheckOutLongitude,
		&attendance.Status, &attendance.LateReason, &attendance.InternName,
	)

	if err != nil {
		utils.RespondNotFound(w, "Attendance not found")
		return
	}

	utils.RespondSuccess(w, "Attendance retrieved successfully", attendance)
}

// GetByInternID retrieves attendance history for a specific intern
func (h *AttendanceHandler) GetByInternID(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	internID, err := strconv.ParseInt(vars["id"], 10, 64)
	if err != nil {
		utils.RespondBadRequest(w, "Invalid intern ID")
		return
	}

	// Parse pagination and date filters
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if page < 1 {
		page = 1
	}
	if limit < 1 {
		limit = 30
	}
	offset := (page - 1) * limit

	startDate := r.URL.Query().Get("start_date")
	endDate := r.URL.Query().Get("end_date")

	query := `
		SELECT id, intern_id, date, check_in_time, check_out_time, status, late_reason
		FROM attendances
		WHERE intern_id = ?
	`
	args := []interface{}{internID}

	if startDate != "" && endDate != "" {
		query += " AND date BETWEEN ? AND ?"
		args = append(args, startDate, endDate)
	}

	query += " ORDER BY date DESC LIMIT ? OFFSET ?"
	args = append(args, limit, offset)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		utils.RespondInternalError(w, "Database error")
		return
	}
	defer rows.Close()

	var attendances []models.Attendance
	for rows.Next() {
		var a models.Attendance
		err := rows.Scan(
			&a.ID, &a.InternID, &a.Date, &a.CheckInTime,
			&a.CheckOutTime, &a.Status, &a.LateReason,
		)
		if err != nil {
			continue
		}
		attendances = append(attendances, a)
	}

	// Get total count
	var total int64
	countQuery := "SELECT COUNT(*) FROM attendances WHERE intern_id = ?"
	countArgs := []interface{}{internID}
	if startDate != "" && endDate != "" {
		countQuery += " AND date BETWEEN ? AND ?"
		countArgs = append(countArgs, startDate, endDate)
	}
	h.db.QueryRow(countQuery, countArgs...).Scan(&total)

	pagination := utils.CalculatePagination(page, limit, total)
	utils.RespondPaginated(w, attendances, pagination)
}

// GetToday retrieves today's attendance for current user
func (h *AttendanceHandler) GetToday(w http.ResponseWriter, r *http.Request) {
	claims, ok := middleware.GetUserFromContext(r.Context())
	if !ok {
		utils.RespondUnauthorized(w, "Unauthorized")
		return
	}

	if claims.Role != "intern" {
		utils.RespondForbidden(w, "Only interns can view their attendance")
		return
	}

	// Get intern ID
	var internID int64
	err := h.db.QueryRow("SELECT id FROM interns WHERE user_id = ?", claims.UserID).Scan(&internID)
	if err != nil {
		utils.RespondNotFound(w, "Intern not found")
		return
	}

	today := time.Now().Format("2006-01-02")
	var attendance models.Attendance
	err = h.db.QueryRow(
		`SELECT id, intern_id, date, check_in_time, check_out_time, status, late_reason
		 FROM attendances
		 WHERE intern_id = ? AND date = ?`,
		internID, today,
	).Scan(
		&attendance.ID, &attendance.InternID, &attendance.Date,
		&attendance.CheckInTime, &attendance.CheckOutTime,
		&attendance.Status, &attendance.LateReason,
	)

	if err == sql.ErrNoRows {
		utils.RespondSuccess(w, "No attendance record for today", map[string]interface{}{
			"checked_in": false,
			"date":       today,
		})
		return
	}

	if err != nil {
		utils.RespondInternalError(w, "Database error")
		return
	}

	utils.RespondSuccess(w, "Today's attendance", map[string]interface{}{
		"checked_in": true,
		"attendance": attendance,
	})
}
