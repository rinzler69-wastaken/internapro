package handlers

import (
	"database/sql"
	"net/http"

	"dsi_interna_sys/internal/utils"
)

type InternHandler struct {
	db *sql.DB
}

func NewInternHandler(db *sql.DB) *InternHandler {
	return &InternHandler{db: db}
}

func (h *InternHandler) GetAll(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - List all interns with pagination
	utils.RespondSuccess(w, "Get all interns - Not implemented yet", nil)
}

func (h *InternHandler) GetByID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get single intern by ID
	utils.RespondSuccess(w, "Get intern by ID - Not implemented yet", nil)
}

func (h *InternHandler) Create(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Create new intern
	utils.RespondSuccess(w, "Create intern - Not implemented yet", nil)
}

func (h *InternHandler) Update(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Update existing intern
	utils.RespondSuccess(w, "Update intern - Not implemented yet", nil)
}

func (h *InternHandler) Delete(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Delete intern
	utils.RespondSuccess(w, "Delete intern - Not implemented yet", nil)
}
