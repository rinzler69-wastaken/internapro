package handlers

import (
	"database/sql"
	"net/http"

	"dsi_interna_sys/internal/utils"
)

type TaskHandler struct {
	db *sql.DB
}

func NewTaskHandler(db *sql.DB) *TaskHandler {
	return &TaskHandler{db: db}
}

func (h *TaskHandler) GetAll(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - List all tasks
	utils.RespondSuccess(w, "Get all tasks - Not implemented yet", nil)
}

func (h *TaskHandler) GetByID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get task by ID
	utils.RespondSuccess(w, "Get task by ID - Not implemented yet", nil)
}

func (h *TaskHandler) GetByInternID(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Get tasks for specific intern
	utils.RespondSuccess(w, "Get tasks by intern ID - Not implemented yet", nil)
}

func (h *TaskHandler) Create(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Create new task
	utils.RespondSuccess(w, "Create task - Not implemented yet", nil)
}

func (h *TaskHandler) Update(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Update task
	utils.RespondSuccess(w, "Update task - Not implemented yet", nil)
}

func (h *TaskHandler) Delete(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Delete task
	utils.RespondSuccess(w, "Delete task - Not implemented yet", nil)
}

func (h *TaskHandler) UploadAttachment(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Upload file attachment
	// Use utils.UploadFile() for file handling
	// Validate: jpg, jpeg, png, pdf only
	utils.RespondSuccess(w, "Upload attachment - Not implemented yet", nil)
}

func (h *TaskHandler) MarkComplete(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement - Mark task as completed
	utils.RespondSuccess(w, "Mark task complete - Not implemented yet", nil)
}
