package main

import (
	"database/sql"
	"fmt"
	"log"
	"os"

	_ "github.com/go-sql-driver/mysql"
	"github.com/joho/godotenv"
	"golang.org/x/crypto/bcrypt"
)

func main() {
	// Load .env file
	godotenv.Load()

	// Database connection
	dbUser := os.Getenv("DB_USER")
	dbPass := os.Getenv("DB_PASSWORD")
	dbHost := os.Getenv("DB_HOST")
	dbPort := os.Getenv("DB_PORT")
	dbName := os.Getenv("DB_NAME")

	if dbUser == "" {
		dbUser = "root"
	}
	if dbHost == "" {
		dbHost = "localhost"
	}
	if dbPort == "" {
		dbPort = "3306"
	}
	if dbName == "" {
		dbName = "interna_db"
	}

	dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?parseTime=true",
		dbUser, dbPass, dbHost, dbPort, dbName)

	db, err := sql.Open("mysql", dsn)
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}
	defer db.Close()

	if err := db.Ping(); err != nil {
		log.Fatal("Failed to ping database:", err)
	}

	fmt.Println("✅ Connected to database")
	fmt.Println("")

	// Create default accounts
	createDefaultAccounts(db)

	fmt.Println("")
	fmt.Println("🎉 Seed data created successfully!")
	fmt.Println("")
	fmt.Println("📝 Default Accounts:")
	fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	fmt.Println("")
	fmt.Println("👤 Admin Account:")
	fmt.Println("   Email:    admin@interna.com")
	fmt.Println("   Password: admin123")
	fmt.Println("")
	fmt.Println("👨‍💼 Supervisor Account:")
	fmt.Println("   Email:    supervisor@interna.com")
	fmt.Println("   Password: supervisor123")
	fmt.Println("")
	fmt.Println("👩‍💻 Intern Account:")
	fmt.Println("   Email:    intern@interna.com")
	fmt.Println("   Password: intern123")
	fmt.Println("")
	fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
}

func createDefaultAccounts(db *sql.DB) {
	// Hash passwords
	adminHash, _ := bcrypt.GenerateFromPassword([]byte("admin123"), bcrypt.DefaultCost)
	supervisorHash, _ := bcrypt.GenerateFromPassword([]byte("supervisor123"), bcrypt.DefaultCost)
	internHash, _ := bcrypt.GenerateFromPassword([]byte("intern123"), bcrypt.DefaultCost)

	// Create Admin
	fmt.Println("Creating admin account...")
	_, err := db.Exec(`
		INSERT INTO users (email, password_hash, role) 
		VALUES (?, ?, ?)
		ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash)
	`, "admin@interna.com", string(adminHash), "admin")
	if err != nil {
		log.Println("⚠️  Admin might already exist:", err)
	} else {
		fmt.Println("✅ Admin account created")
	}

	// Create Supervisor
	fmt.Println("Creating supervisor account...")
	result, err := db.Exec(`
		INSERT INTO users (email, password_hash, role) 
		VALUES (?, ?, ?)
		ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), id=LAST_INSERT_ID(id)
	`, "supervisor@interna.com", string(supervisorHash), "supervisor")
	if err != nil {
		log.Println("⚠️  Supervisor might already exist:", err)
	} else {
		supervisorUserID, _ := result.LastInsertId()

		// Create supervisor profile
		db.Exec(`
			INSERT INTO supervisors (user_id, full_name, nip, position)
			VALUES (?, ?, ?, ?)
			ON DUPLICATE KEY UPDATE full_name = VALUES(full_name)
		`, supervisorUserID, "John Supervisor", "SUP001", "Senior Developer")

		fmt.Println("✅ Supervisor account created")
	}

	// Create Sample Institution
	fmt.Println("Creating sample institution...")
	instResult, err := db.Exec(`
		INSERT INTO institutions (name, address, phone, email)
		VALUES (?, ?, ?, ?)
		ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)
	`, "Tech University", "Jl. Teknologi No. 123, Semarang", "024-1234567", "info@techuniv.edu")
	if err != nil {
		log.Println("⚠️  Institution might already exist:", err)
	}

	institutionID, _ := instResult.LastInsertId()
	if institutionID == 0 {
		db.QueryRow("SELECT id FROM institutions LIMIT 1").Scan(&institutionID)
	}

	// Get supervisor ID
	var supervisorID int64
	db.QueryRow(`
		SELECT s.id FROM supervisors s 
		JOIN users u ON s.user_id = u.id 
		WHERE u.email = ?
	`, "supervisor@interna.com").Scan(&supervisorID)

	// Create Intern
	fmt.Println("Creating intern account...")
	internResult, err := db.Exec(`
		INSERT INTO users (email, password_hash, role) 
		VALUES (?, ?, ?)
		ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), id=LAST_INSERT_ID(id)
	`, "intern@interna.com", string(internHash), "intern")
	if err != nil {
		log.Println("⚠️  Intern might already exist:", err)
	} else {
		internUserID, _ := internResult.LastInsertId()

		// Create intern profile
		db.Exec(`
			INSERT INTO interns (user_id, institution_id, supervisor_id, full_name, student_id, 
			                     date_of_birth, gender, phone, address, start_date, end_date, status)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
			ON DUPLICATE KEY UPDATE full_name = VALUES(full_name)
		`, internUserID, institutionID, supervisorID, "Jane Intern", "INT001",
			"2000-01-01", "female", "081234567890", "Jl. Magang No. 1, Semarang",
			"2026-01-01", "2026-04-01", "active")

		fmt.Println("✅ Intern account created")
	}
}
